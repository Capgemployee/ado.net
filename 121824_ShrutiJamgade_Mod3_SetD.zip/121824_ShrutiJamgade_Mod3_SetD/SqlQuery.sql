
--Table Creation for Customer
CREATE TABLE Customer_DN121824
(
	CustomerID int PRIMARY KEY IDENTITY(1,1),
	CustomerName varchar(30),
	Address varchar(30),
	Landmark varchar(20),
	City varchar(10),
	Pincode numeric(6),
	ContactNo bigint,
	EmailID varchar(30)
)

SELECT * FROM Customer_DN121824

DROP TABLE Customer_DN121824

--Stored Procedure for Adding the Customer Record
CREATE PROCEDURE AddCust_DN121824
(
	@CustomerID int OUT,
	@CustomerName varchar(30),
	@Address varchar(30),
	@Landmark varchar(20),
	@City varchar(10),
	@Pincode numeric(6),
	@ContactNo bigint,
	@EmailID varchar(30)
)
AS
INSERT INTO Customer_DN121824
VALUES(@CustomerName,@Address,@Landmark,@City,@Pincode,@ContactNo,@EmailID)

--Stored Procedure for Displaying the Customer Record
CREATE PROCEDURE DisplayCust_DN121824
AS
SELECT * FROM Customer_DN121824



