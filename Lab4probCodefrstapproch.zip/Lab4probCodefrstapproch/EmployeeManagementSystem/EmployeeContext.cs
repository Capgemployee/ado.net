﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;

namespace EmployeeManagementSystem
{
    class EmployeeContext : DbContext
    {
        public EmployeeContext()
            : base()
        { }

        public DbSet<EmployeeCB> EmpTable { get; set; }
    }
}
