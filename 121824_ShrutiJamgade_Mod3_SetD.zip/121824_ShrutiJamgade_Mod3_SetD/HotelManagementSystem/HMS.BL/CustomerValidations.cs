﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Data;
using HMS.Entity;               //Taking Reference of Entity Classes
using HMS.Exception;              //Taking Reference of Exception Classes
using HMS.DAL;                     //Taking Reference of DAL Classes

namespace HMS.BL
{
    /// <summary>
    /// Employee ID :121824
    /// Employee Name : SHRUTI JAMGADE
    /// Description : Customer validation class to validate the Customer data
    /// Date of Creation :  03/14/2017
    /// </summary>
    public class CustomerValidations
    {
        CustomerOperations custValidate = new CustomerOperations();

        public bool ValidateCustomer(Customer custObj)
        {
            bool validCustomer = true;
            StringBuilder sb = new StringBuilder();
            //Making all the fields mandatory
            if (custObj.CustomerName.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Name is required.");
            }
            if (custObj.Address.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Address is required.");
            }
            if (custObj.Landmark.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Landmark is required.");
            }
            if (custObj.City.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "City Name is required.");
            }
            if (custObj.PinCode.ToString().Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Pincode is required.");
            }
            if (custObj.ContactNo.ToString().Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Customer Contact No is required.");
            }
            if (custObj.EmailID.Length == 0)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Email Id is required.");
            }
            //Validation for customer name
            if (!(Regex.IsMatch(custObj.CustomerName, @"^[a-zA-Z ]+$")))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Employee Name should contain only characters.");
            }
            //Validation for pincode
            if (!(Regex.IsMatch(custObj.PinCode.ToString(), @"^[0-9]+$")))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Pincode should contain only numbers.");
            }
            if (custObj.PinCode.ToString().Length != 6)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Pincode should consist of 6 digits only.");
            }
            //Validation for Phone no
            if (!(Regex.IsMatch(custObj.ContactNo.ToString(), @"^[0-9]+$")))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Contact number should contain only numbers.");
            }
            if (custObj.ContactNo.ToString().Length != 10)
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            }
            //Validating EmaIL id
            string pattern = null;
            pattern = "@^[a-zA-Z ][0-9]@[a-zA-Z ].com";

            if (Regex.IsMatch(custObj.EmailID, pattern))
            {
                validCustomer = false;
                sb.Append(Environment.NewLine + "Email address should be in feedback@gmail.com pattern");
            }
            
            if (validCustomer == false)
                throw new CustomerException(sb.ToString());
            return validCustomer;
        }

        //Validating Add Method
        public bool AddCustomerRecord(Customer custObj)
        {
         bool customerAdded = false;

            try 
            {
                if (ValidateCustomer(custObj))
                {
                    customerAdded = custValidate.AddCustomerRecord(custObj);
                }
                else
                {
                    throw new CustomerException("Employee Details are invalid");
                }
            }
            catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }

            return customerAdded;
        }


        //Validating Display Method
        public DataTable DisplayGuestRecord()
        {
          try 
            {
                DataTable customerTable = custValidate.DisplayGuestRecord();
                return customerTable;
            }
          catch (CustomerException ex)
            {
                throw ex;
            }
            catch (SystemException ex)
            {
                throw ex;
            }
        }
    }
}
