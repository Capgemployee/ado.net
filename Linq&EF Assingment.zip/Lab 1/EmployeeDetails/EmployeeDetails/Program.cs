﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EmployeeDetails
{
    public class Employee
    {
        public  int EmployeeID { get; set; }
        public  string FirstName { get; set; }
        public  string LastName { get; set; }
        public  string Title { get; set; }
        public  DateTime DOB { get; set; }
        public  DateTime DOJ { get; set; }
        public  string City { get; set; }
        

        static void Main(string[] args)
        {
            List<Employee> emplist = new List<Employee>()
            {
            new Employee { EmployeeID = 1001, FirstName = "John", LastName = "Smith\t", Title = "Software Engineer", DOB = new DateTime(03/17/1995), DOJ = new DateTime (01/18/2017), City = "Pune" } ,
            new Employee { EmployeeID = 1002, FirstName = "Sam", LastName = "Modi\t", Title = "Analyst", DOB = new DateTime(05/10/1994), DOJ = Convert.ToDateTime (03/21/2012), City = "Pune" } ,
            new Employee { EmployeeID = 1003, FirstName = "Mathew", LastName = "Thomson\t", Title = "AsstManager", DOB = new DateTime(21/12/1993), DOJ = new DateTime(08/11/1999), City = "Bangalore" } ,
            new Employee { EmployeeID = 1004, FirstName = "Black", LastName = "Smith\t", Title = "Director", DOB = new DateTime(05/18/1994), DOJ = new DateTime(06/18/1995), City = "Mumbai" },
            };

            var empdetails = from e in emplist
                             select e;
            Console.WriteLine("Display details:");

            foreach (var item in empdetails)
            {
                Console.WriteLine("{0} {1} {2} {3}", item.EmployeeID, item.FirstName, item.LastName, item.Title, item.DOB, item.DOJ, item.City);
            }
            Console.WriteLine();

            var emploc = from e in emplist
                         where e.City != "Mumbai"
                         select e;
                         Console.WriteLine("Display Details of all the Employees whose city is not Mumbai");

                         foreach (var item in emploc)
                         {
                             Console.WriteLine("{0} {1} {2} {3}", item.EmployeeID, item.FirstName, item.LastName, item.Title, item.DOB, item.DOJ, item.City);
                         }
                         Console.WriteLine();
            var emptitle = from e in emplist
                         where e.Title == "AsstManager"
                         select e;
                         Console.WriteLine("Display the details of AsstManager");
                         foreach (var item in emptitle)
                         {
                             Console.WriteLine("{0} {1} {2} {3}", item.EmployeeID, item.FirstName, item.LastName, item.Title, item.DOB, item.DOJ, item.City);
                         }
                         Console.WriteLine();

            var emplstn = from e in emplist
                         where e.LastName.StartsWith("S")
                         select e;
                         Console.WriteLine("Display the Employee Details whose Last Name Start with S");
                         foreach (var item in emplstn)
                         {
                             Console.WriteLine("{0} {1} {2} {3}", item.EmployeeID, item.FirstName, item.LastName, item.Title, item.DOB, item.DOJ, item.City);
                         }
                         Console.WriteLine();

            var empjd = from e in emplist
                         where e.DOJ < new DateTime(01/01/2015)
                         select e;
                         Console.WriteLine("Display all the details whose joining date is before 01/01/2015");
                         foreach (var item in empjd)
                         {
                             Console.WriteLine("{0} {1} {2} {3}", item.EmployeeID, item.FirstName, item.LastName, item.Title, item.DOB, item.DOJ, item.City);
                         }
                         Console.WriteLine();

            var emptotal = (from e in emplist
                         select e).Count();
                         Console.WriteLine("Total Employees" + emptotal);
                         Console.ReadKey();       

        }
    } 
}
