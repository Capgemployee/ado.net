﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entity
{
    /// <summary>
    /// Employee ID :121825
    /// Employee Name : Shubham Agrawal
    /// Description : This class will have the Patient Structure
    /// Version:1.0
    /// Last Modified Date : 14-March-2017
    /// Date of Creation : 14-March-2017
    /// </summary>
    public class Patient
    {
        //Get Patient Id
        public int PatientID { get; set; }

        //Get or Set First Name
        public string FirstName { get; set; }

        //Get or Set Last Name
        public string LastName { get; set; }

        //Get or Set Gender
        public string Gender { get; set; }

        //Get or Set DateAndTime
        public string DateAndTime { get; set; }

        //Get or Set Address
        public string Address { get; set; }

        //Get or Set City
        public string City { get; set; }

        //Get or Set State
        public string State { get; set; }

        //Get or Set Pincode
        public string Pincode { get; set; }

        //Get or Set Mobile Number
        public string Mobile { get; set; }

    }
}
