﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace EmployeeManagementSystem
{
    class EmployeeCB
    {
        [Key]
        public int Empno { get; set; }
        public string Empname { get; set; }
        public DateTime EmpDOB { get; set; }
        public DateTime EmpDOJ { get; set; }
        public string EmpDesg { get; set; }
        public Double EmpSal { get; set; }
    }
}
