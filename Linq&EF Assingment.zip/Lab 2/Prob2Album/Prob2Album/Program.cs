﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Prob2Album
{
    class Program
    {
        static void Main(string[] args)
        {
            Training_18Jan2017_TalwadeEntities musicentity = new Training_18Jan2017_TalwadeEntities();
            var albums = from a in musicentity.Albums
                         select a;
            //var albums = musicentity.Albums;
            
         
            foreach (Album a in albums)
                Console.WriteLine(a.AlbumID + "\t" + a.Name + "\t" + a.Price);

            Album alb = new Album()
            {
            AlbumID = 1011,
            Name="Sanam Puri",
            Genre="Vocal",
            Price=199,
            };
            musicentity.Albums.Add(alb);
            musicentity.SaveChanges();
            
            Console.ReadLine();
        }
    }
}
