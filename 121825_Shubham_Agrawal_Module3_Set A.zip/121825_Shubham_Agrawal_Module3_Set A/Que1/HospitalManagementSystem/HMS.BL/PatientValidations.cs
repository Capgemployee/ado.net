﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Entity;
using HMS.Exception;
using HMS.DAL;
using System.Data;
using System.Text.RegularExpressions;

namespace HMS.BL
{
    /// <summary>
    /// Employee ID :121825
    /// Employee Name : Shubham Agrawal
    /// Description : Patient validation class to deal with all validations of the Patient data
    /// Version:1.0
    /// Last Modified Date : 14-March-2017
    /// Date of Creation : 14-March-2017
    /// </summary>
    public class PatientValidations
    {
        PatientOperations operationObj = new PatientOperations();

        /// <summary>
        /// Method to Patient Guest record
        /// Author: Shubham Agrawal
        /// Date Modified: 14-March-2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="patientObj"></param>
        /// <returns></returns>
        public bool ValidatePatient(Patient patientObj)
        {
            bool validPatient = true;
            
            StringBuilder sb = new StringBuilder();
            if (patientObj.PatientID.ToString().Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient ID is required.");
            }
            if (patientObj.FirstName.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "first Name is required.");
            }
            if (patientObj.LastName.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Last Name is required.");
            }
            if (patientObj.Gender.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "gender is required.");
            }
            if (patientObj.DateAndTime.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "date and time is required.");
            }
            if (patientObj.Address.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Address is required.");
            }
            if (patientObj.City.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "City is required.");
            }
            if (patientObj.State.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "State is required.");
            }
            if (patientObj.Pincode.Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Pincode is required.");
            }
            if (patientObj.Mobile.ToString().Length == 0)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Patient Contact No is required.");
            }
            if (!(Regex.IsMatch(patientObj.FirstName, @"^[a-zA-Z ]+$")))
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "first Name should contain only characters.");
            }
            if (!(Regex.IsMatch(patientObj.LastName, @"^[a-zA-Z ]+$")))
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "last Name should contain only characters.");
            }

            if (!(Regex.IsMatch(patientObj.State, @"^[a-zA-Z ]+$")))
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "state should contain only characters.");
            }
            if (patientObj.Mobile.ToString().Length != 10)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Conatct No should consist of 10 digits only.");
            }

            if (patientObj.Pincode.ToString().Length != 6)
            {
                validPatient = false;
                sb.Append(Environment.NewLine + "Pincode should consist of 6 digits only.");
            }
            if (validPatient == false)
                throw new PatientException(sb.ToString());
            return validPatient;
        
        }
        /// <summary>
        /// Method that calls a method that adds a Patient Record
        /// Author: Shubham Agrawal
        /// Date Modified: 14-March-2017
        /// Version No:
        /// Change Description:
        /// </summary>
        /// <param name="patientObj"></param>
        /// <returns>bool</returns>
        public bool AddPatientRecord(Patient patientObj)
        {
            bool patientAdded = false;
            if (ValidatePatient(patientObj))
                patientAdded = operationObj.AddPatientRecord(patientObj);
            return patientAdded;
        }

        /// <summary>
        /// Method that calls a method that returns the patient information
        /// Author: Shubham Agrawal
        /// Date Modified: 14-March-2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="patientID"></param>
        /// <returns>DataTable</returns>
        public DataTable GetPatientRecord(int patientID)
        {

            DataTable patientTable = operationObj.GetPatientRecord(patientID);
            return patientTable;
        }
    }
}
