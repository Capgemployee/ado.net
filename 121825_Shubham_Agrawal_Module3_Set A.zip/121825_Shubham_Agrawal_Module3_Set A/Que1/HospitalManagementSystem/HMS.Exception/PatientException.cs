﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Exception
{
    /// <summary>
    /// Employee ID :121825
    /// Employee Name : Shubham Agrawal
    /// Description : User defined Exception class for Consumer
    /// Version:1.0
    /// Last Modified Date : 14-March-2017
    /// Date of Creation : 14-March-2017
    /// </summary>
    public class PatientException : ApplicationException
    {
        public PatientException() : base() { }
        public PatientException(string message) : base(message) { }
    }

}


