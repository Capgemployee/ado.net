﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPE.CustomException
{
    /// <summary>
    /// Class to throw Custom Exceptions
    /// Author: Miss.Shraddha Surve
    /// Date Modified: 14 March 2017
    /// Version No:1
    /// Change Description: This class will have the User Defined Exception class for Trainee
    /// </summary>
    public class TraineeExceptions : ApplicationException
    {
        public TraineeExceptions() : base() { }
        public TraineeExceptions(string message) : base(message) { }
    }
}
