﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        private void btnShow_Click(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.RowFilter = "City like " + txtCity.Text + "";
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;Integrated Security=False;User ID=sqluser;Password=sqluser;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
            con.Open();
            ds = new DataSet();
            da = new SqlDataAdapter("select * from customer1_121699",con);
            da.Fill(ds, "cust");
            grdCustomers.DataSource=ds.Tables["cust"];
        }

        private void CMBColumnList_SelectedIndexChanged(object sender, EventArgs e)
        {
            ds.Tables["cust"].DefaultView.Sort = CMBColumnList.Text;
        }
    }
}
