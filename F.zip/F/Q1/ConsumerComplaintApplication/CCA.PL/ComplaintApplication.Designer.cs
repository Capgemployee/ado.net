﻿namespace CCA.PL
{
    partial class ComplaintApplication
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.txtEID = new System.Windows.Forms.TextBox();
            this.btn_Verify = new System.Windows.Forms.Button();
            this.mainPanel = new System.Windows.Forms.Panel();
            this.comboBox1 = new System.Windows.Forms.ComboBox();
            this.label4 = new System.Windows.Forms.Label();
            this.txtDealerDet = new System.Windows.Forms.TextBox();
            this.txtCompDet = new System.Windows.Forms.TextBox();
            this.txtProdName = new System.Windows.Forms.TextBox();
            this.dateOfPurch = new System.Windows.Forms.DateTimePicker();
            this.txtProdValue = new System.Windows.Forms.TextBox();
            this.txtCity = new System.Windows.Forms.TextBox();
            this.btn_Register = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.label10 = new System.Windows.Forms.Label();
            this.label9 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.label7 = new System.Windows.Forms.Label();
            this.label6 = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.registerLink = new System.Windows.Forms.LinkLabel();
            this.mainPanel.SuspendLayout();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Microsoft Sans Serif", 18F);
            this.label1.Location = new System.Drawing.Point(154, 27);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(289, 29);
            this.label1.TabIndex = 0;
            this.label1.Text = "Do You have Grievance??";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(50, 85);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(96, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Enter your email ID";
            // 
            // txtEID
            // 
            this.txtEID.Location = new System.Drawing.Point(169, 85);
            this.txtEID.Name = "txtEID";
            this.txtEID.Size = new System.Drawing.Size(231, 20);
            this.txtEID.TabIndex = 1;
            // 
            // btn_Verify
            // 
            this.btn_Verify.Location = new System.Drawing.Point(428, 80);
            this.btn_Verify.Name = "btn_Verify";
            this.btn_Verify.Size = new System.Drawing.Size(130, 23);
            this.btn_Verify.TabIndex = 2;
            this.btn_Verify.Text = "Verify email ID";
            this.btn_Verify.UseVisualStyleBackColor = true;
            this.btn_Verify.Click += new System.EventHandler(this.btn_Verify_Click);
            // 
            // mainPanel
            // 
            this.mainPanel.Controls.Add(this.comboBox1);
            this.mainPanel.Controls.Add(this.label4);
            this.mainPanel.Controls.Add(this.txtDealerDet);
            this.mainPanel.Controls.Add(this.txtCompDet);
            this.mainPanel.Controls.Add(this.txtProdName);
            this.mainPanel.Controls.Add(this.dateOfPurch);
            this.mainPanel.Controls.Add(this.txtProdValue);
            this.mainPanel.Controls.Add(this.txtCity);
            this.mainPanel.Controls.Add(this.btn_Register);
            this.mainPanel.Controls.Add(this.label11);
            this.mainPanel.Controls.Add(this.label10);
            this.mainPanel.Controls.Add(this.label9);
            this.mainPanel.Controls.Add(this.label8);
            this.mainPanel.Controls.Add(this.label7);
            this.mainPanel.Controls.Add(this.label6);
            this.mainPanel.Controls.Add(this.label5);
            this.mainPanel.Location = new System.Drawing.Point(32, 134);
            this.mainPanel.Name = "mainPanel";
            this.mainPanel.Size = new System.Drawing.Size(526, 353);
            this.mainPanel.TabIndex = 5;
            // 
            // comboBox1
            // 
            this.comboBox1.FormattingEnabled = true;
            this.comboBox1.Items.AddRange(new object[] {
            "Domestic",
            "Commercial",
            "Educational",
            "Medicine",
            "Other"});
            this.comboBox1.Location = new System.Drawing.Point(183, 23);
            this.comboBox1.Name = "comboBox1";
            this.comboBox1.Size = new System.Drawing.Size(121, 21);
            this.comboBox1.TabIndex = 4;
            this.comboBox1.Text = "Domestic";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(17, 0);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(119, 13);
            this.label4.TabIndex = 0;
            this.label4.Text = "Complaint/Enquiry Form";
            // 
            // txtDealerDet
            // 
            this.txtDealerDet.Location = new System.Drawing.Point(183, 125);
            this.txtDealerDet.Multiline = true;
            this.txtDealerDet.Name = "txtDealerDet";
            this.txtDealerDet.Size = new System.Drawing.Size(191, 40);
            this.txtDealerDet.TabIndex = 7;
            // 
            // txtCompDet
            // 
            this.txtCompDet.Location = new System.Drawing.Point(183, 258);
            this.txtCompDet.Multiline = true;
            this.txtCompDet.Name = "txtCompDet";
            this.txtCompDet.Size = new System.Drawing.Size(200, 52);
            this.txtCompDet.TabIndex = 10;
            // 
            // txtProdName
            // 
            this.txtProdName.Location = new System.Drawing.Point(183, 58);
            this.txtProdName.Name = "txtProdName";
            this.txtProdName.Size = new System.Drawing.Size(121, 20);
            this.txtProdName.TabIndex = 5;
            // 
            // dateOfPurch
            // 
            this.dateOfPurch.Location = new System.Drawing.Point(183, 92);
            this.dateOfPurch.Name = "dateOfPurch";
            this.dateOfPurch.Size = new System.Drawing.Size(200, 20);
            this.dateOfPurch.TabIndex = 6;
            // 
            // txtProdValue
            // 
            this.txtProdValue.Location = new System.Drawing.Point(183, 181);
            this.txtProdValue.Name = "txtProdValue";
            this.txtProdValue.Size = new System.Drawing.Size(121, 20);
            this.txtProdValue.TabIndex = 8;
            // 
            // txtCity
            // 
            this.txtCity.Location = new System.Drawing.Point(183, 217);
            this.txtCity.Name = "txtCity";
            this.txtCity.Size = new System.Drawing.Size(121, 20);
            this.txtCity.TabIndex = 9;
            // 
            // btn_Register
            // 
            this.btn_Register.Location = new System.Drawing.Point(135, 316);
            this.btn_Register.Name = "btn_Register";
            this.btn_Register.Size = new System.Drawing.Size(228, 23);
            this.btn_Register.TabIndex = 11;
            this.btn_Register.Text = "Register your complaint";
            this.btn_Register.UseVisualStyleBackColor = true;
            this.btn_Register.Click += new System.EventHandler(this.btn_Register_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.Location = new System.Drawing.Point(43, 261);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(93, 13);
            this.label11.TabIndex = 6;
            this.label11.Text = "Complaints Details";
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(43, 217);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(24, 13);
            this.label10.TabIndex = 5;
            this.label10.Text = "City";
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(43, 181);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(74, 13);
            this.label9.TabIndex = 4;
            this.label9.Text = "Product Value";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(43, 125);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(113, 13);
            this.label8.TabIndex = 3;
            this.label8.Text = "Dealer Name & Address";
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Location = new System.Drawing.Point(43, 92);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(89, 13);
            this.label7.TabIndex = 2;
            this.label7.Text = "Date of purchase";
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(43, 58);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(75, 13);
            this.label6.TabIndex = 1;
            this.label6.Text = "Product Name";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Location = new System.Drawing.Point(43, 32);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(49, 13);
            this.label5.TabIndex = 0;
            this.label5.Text = "Category";
            // 
            // registerLink
            // 
            this.registerLink.ActiveLinkColor = System.Drawing.Color.Silver;
            this.registerLink.AutoSize = true;
            this.registerLink.DisabledLinkColor = System.Drawing.Color.FromArgb(((int)(((byte)(64)))), ((int)(((byte)(64)))), ((int)(((byte)(64)))));
            this.registerLink.LinkColor = System.Drawing.Color.Black;
            this.registerLink.LinkVisited = true;
            this.registerLink.Location = new System.Drawing.Point(428, 61);
            this.registerLink.Name = "registerLink";
            this.registerLink.Size = new System.Drawing.Size(150, 13);
            this.registerLink.TabIndex = 3;
            this.registerLink.TabStop = true;
            this.registerLink.Text = "Register your complaint here...";
            this.registerLink.LinkClicked += new System.Windows.Forms.LinkLabelLinkClickedEventHandler(this.registerLink_LinkClicked);
            // 
            // ComplaintApplication
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(586, 519);
            this.Controls.Add(this.registerLink);
            this.Controls.Add(this.mainPanel);
            this.Controls.Add(this.btn_Verify);
            this.Controls.Add(this.txtEID);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label1);
            this.Name = "ComplaintApplication";
            this.Text = "ConsumerComplaint";
            this.mainPanel.ResumeLayout(false);
            this.mainPanel.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.TextBox txtEID;
        private System.Windows.Forms.Button btn_Verify;
        private System.Windows.Forms.Panel mainPanel;
        private System.Windows.Forms.ComboBox comboBox1;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtDealerDet;
        private System.Windows.Forms.TextBox txtCompDet;
        private System.Windows.Forms.TextBox txtProdName;
        private System.Windows.Forms.DateTimePicker dateOfPurch;
        private System.Windows.Forms.TextBox txtProdValue;
        private System.Windows.Forms.TextBox txtCity;
        private System.Windows.Forms.Button btn_Register;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.LinkLabel registerLink;
    }
}

