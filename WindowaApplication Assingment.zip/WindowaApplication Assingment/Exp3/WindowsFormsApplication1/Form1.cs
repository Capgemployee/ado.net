﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        public void status()
        {
            toolStripStatusLabel1.Text = "Unsaved";
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Unsaved";
        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (toolStripStatusLabel1.Text == "Unsaved" && toolStripStatusLabel2.Text == String.Empty)
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    FileStream fs = new FileStream(saveFileDialog1.FileName, FileMode.Create, FileAccess.Write);
                    StreamWriter sw = new StreamWriter(fs);
                    Form2 frm2 = new Form2();
                    sw.WriteLine(((TextBox)frm2.Controls["textBox1"]).Text);
                    sw.Flush();
                    fs.Close();
                    toolStripStatusLabel1.Text = "Saved";
                    toolStripStatusLabel2.Text = saveFileDialog1.FileName;
                }
            }
            else if (toolStripStatusLabel1.Text == "Unsaved" && toolStripStatusLabel2.Text != String.Empty)
            {
                FileStream fs = new FileStream(toolStripStatusLabel2.Text, FileMode.Open, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                Form2 frm2 = new Form2();
                sw.WriteLine(((TextBox)frm2.Controls["textBox1"]).Text);
                sw.Flush();
                fs.Close();
                toolStripStatusLabel1.Text = "Saved";
                toolStripStatusLabel2.Text = saveFileDialog1.FileName;
            }

            
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {
            Form2 frm2 = new Form2();
            frm2.MdiParent = this;
            frm2.Show();
        }
    }
}
