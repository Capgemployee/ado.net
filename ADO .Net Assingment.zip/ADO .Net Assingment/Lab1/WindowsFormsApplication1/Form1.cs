﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            
        }

        private void btnQuery_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;Integrated Security=False;User ID=sqluser;Password=sqluser;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
                con.Open();
                SqlDataReader reader = null;
                SqlCommand cmd = new SqlCommand("GetEmployeeById_121699", con);
                cmd.CommandType = CommandType.StoredProcedure;

                SqlParameter prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);

                cmd.Parameters["@eno"].Value = int.Parse(txtEmpno.Text);

                reader = cmd.ExecuteReader();

                if (reader.Read())
                {
                    txtEmpname.Text = reader["empname"].ToString();
                    txtSalary.Text = reader["empsal"].ToString();
                    if (reader["emptype"].ToString() == "P")
                    {
                        radioPayrol.Checked = true;
                    }
                    else
                    {
                        radioContract.Checked = true;
                    }
                    btnDelete.Enabled = true;
                }
                else
                {
                    btnNew_Click(btnNew, e);
                    MessageBox.Show("No Such Employee");
                }
                reader.Close();
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnNew_Click(object sender, EventArgs e)
        {
            txtEmpno.Text = "";
            txtEmpname.Text = "";
            txtSalary.Text = "";
            txtEmpno.Focus();
            btnDelete.Enabled = false;
        }

        private void btnSave_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;Integrated Security=False;User ID=sqluser;Password=sqluser;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
                SqlCommand cmd = new SqlCommand("insert into employee_121699 values(@eno,@enm,@esal,@etype)", con);
                con.Open();
                cmd.Parameters.Add("@eno",SqlDbType.Int);
                cmd.Parameters.Add("@enm",SqlDbType.VarChar,50);
                cmd.Parameters.Add("@esal",SqlDbType.Decimal);
                cmd.Parameters.Add("@etype",SqlDbType.VarChar,1);

                cmd.Parameters["@eno"].Value = txtEmpno.Text;
                cmd.Parameters["@enm"].Value = txtEmpname.Text;
                cmd.Parameters["@esal"].Value = txtSalary.Text;
                cmd.Parameters["@etype"].Value = radioPayrol.Checked == true ? "P" : "C";

                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved");
                con.Close();
                btnDelete.Enabled = false;
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;Integrated Security=False;User ID=sqluser;Password=sqluser;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
                SqlCommand cmd = new SqlCommand("delete from employee_121699 where empno=@eno", con);
                con.Open();
                cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters["@eno"].Value = txtEmpno.Text;
                
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Deleted");
                con.Close();
                txtEmpno.Text = "";
                txtEmpname.Text = "";
                txtSalary.Text = "";
                txtEmpno.Focus();
                btnDelete.Enabled = false; 
            }

            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnSave2_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;Integrated Security=False;User ID=sqluser;Password=sqluser;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
                con.Open();
                SqlDataReader reader = null;
                SqlCommand cmd = new SqlCommand("inEmployee_121699", con);
                cmd.CommandType = CommandType.StoredProcedure;

                cmd.Parameters.AddWithValue("@empname",txtEmpname.Text);
                cmd.Parameters.AddWithValue("@empsal",Convert.ToInt32(txtSalary.Text));
                cmd.Parameters.AddWithValue("@emptype", radioPayrol.Checked == true ? "P" : "C");
                
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee detials added");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }
    }
}
