﻿// Default code generation is disabled for model 'D:\.Net 2017\Arti\EXAM\Module 3\121649_ArtiLanke_Module3_SetF\Q2\Display\Display\Model1.edmx'. 
// To enable default code generation, change the value of the 'Code Generation Strategy' designer
// property to an alternate value. This property is available in the Properties Window when the model is
// open in the designer.