﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using HMS.Entity;
using HMS.Exception;
using HMS.BL;
using System.Data.SqlClient;

namespace HMS.PL
{
    public partial class CustomerInteraction : Form
    {
        CustomerValidations validationsObj = new CustomerValidations();
        public CustomerInteraction()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }
        private void btnAdd_Click(object sender, EventArgs e)
        {
            try
            {
                Customer custObj = new Customer();
                custObj.CustomerName = txtCustomerName.Text;
                custObj.Address = txtAddress.Text;
                custObj.Landmark = txtLandmark.Text;
                custObj.City = txtCity.Text;
                bool isNumber;
                int pinCode;
                isNumber = int.TryParse(txtPinCode.Text, out pinCode);
                if (isNumber)
                    custObj.PinCode = pinCode;
                else
                {
                    MessageBox.Show("Please enter only numbers in PinCode ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                long contactNo;
                isNumber = long.TryParse(txtContactNo.Text, out contactNo);
                if (isNumber)
                    custObj.ContactNo = contactNo;
                else
                {
                    MessageBox.Show("Please enter only numbers in Conatct No field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }

                custObj.EmailID = txtEmailId.Text;

                bool customerAdded = validationsObj.AddCustomerRecord(custObj);
                if (customerAdded)
                {
                    MessageBox.Show("Customer Record Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
                else
                    MessageBox.Show("Failed to add customer record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            try
            {
                DataTable customerTable = new DataTable();
                customerTable = validationsObj.DisplayGuestRecord();
                dgvCustomer.DataSource = customerTable;
            }
            catch (CustomerException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }


        private void dgvCustomer_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtLandmark_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtCity_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPinCode_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox6_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmailId_TextChanged(object sender, EventArgs e)
        {

        }

        private void btnReset_Click(object sender, EventArgs e)
        {
            txtCustomerName.Clear();
            txtAddress.Clear();
            txtLandmark.Clear();
            txtCity.Clear();
            txtPinCode.Clear();
            txtContactNo.Clear();
            txtEmailId.Clear();
        }
    }
}
