﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowaApplication
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Hello My First Window....!!");
            txtDOA.Text = DateTime.Now.ToShortDateString();
        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtDOA_TextChanged(object sender, EventArgs e)
        {

        }

        private void button10_Click(object sender, EventArgs e)
        {
            FileStream stream = new FileStream(FileMode.Open,);
            StreamReader reader = new StreamReader(stream);
            txtData.Text = reader.ReadToEnd();
        }

        private void existToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
