﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;


namespace CodeFirstApprochprt1
{
    class ProductContext : DbContext
    {
        public ProductContext()
            : base()
        { 
        }

        public DbSet<Products_121653> Products_details { get; set; }
    }
}
