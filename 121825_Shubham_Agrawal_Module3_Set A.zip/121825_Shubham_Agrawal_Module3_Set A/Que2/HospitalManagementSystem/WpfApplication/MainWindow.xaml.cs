﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace WpfApplication
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {   
            //new object on entity 
            Training_18Jan2017_TalwadeEntities en = new Training_18Jan2017_TalwadeEntities();


            //linq query for filtering the data
            var query = from p in en.Hospital_121825
                        where p.State=="maharashtr"
                        select p;
            //displaying on datagrid
            dataGrid.ItemsSource = query.ToList();

        }
    }
}
