﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace TPE.Entity
{
    /// <summary>
    /// Entity to store Trainee's Performance Details
    /// Author: Miss.Shraddha Surve
    /// Date Modified: 14 March 2017
    /// Version No:1
    /// Change Description: This class will have the structure of Trainee's details
    /// </summary>
    public class Trainee
    {
        /// <summary>
        /// Property to store and retrieve EmployeeID
        /// </summary>
        public int EmployeeID { get; set; }
        /// <summary>
        /// Property to store and retrieve ModuleName
        /// </summary>
        public string ModuleName { get; set; }
        /// <summary>
        /// Property to store and retrieve Batch Name
        /// </summary>
        public string BatchName { get; set; }
        /// <summary>
        /// Property to store and retrieve Comments
        /// </summary>
        public string Comments { get; set; }
    }
}
