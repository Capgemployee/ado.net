﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace ModuleDetails
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Method to display Module details
        /// Author: Miss.Shraddha Surve
        /// Date Modified: 14 march 2017
        /// Version No:1
        /// Change Description: This is a method to display all module details for .Net batch
        /// </summary>
        private void btnDisplay_Click(object sender, RoutedEventArgs e)
        {
            Training_18Jan2017_TalwadeEntities5 entities =new Training_18Jan2017_TalwadeEntities5();
            var query = from t in entities.TraineePerformance_121823
                        where t.BatchName == ".Net"
                        select new { t.ModuleName, t.BatchName };

                        //OR select t;
            dgrDisplay.ItemsSource = query.ToList();
        }

        private void DataGrid_SelectionChanged_1(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
