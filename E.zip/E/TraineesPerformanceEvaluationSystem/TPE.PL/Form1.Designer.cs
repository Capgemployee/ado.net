﻿namespace TPE.PL
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label4 = new System.Windows.Forms.Label();
            this.txtEmployeeID = new System.Windows.Forms.TextBox();
            this.txtModuleName = new System.Windows.Forms.TextBox();
            this.txtBatchName = new System.Windows.Forms.TextBox();
            this.txtcomments = new System.Windows.Forms.TextBox();
            this.btnaddentry = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(43, 24);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(73, 13);
            this.label1.TabIndex = 0;
            this.label1.Text = "Employee ID :";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(43, 68);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(79, 13);
            this.label2.TabIndex = 1;
            this.label2.Text = "Module Name :";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(43, 111);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(72, 13);
            this.label3.TabIndex = 2;
            this.label3.Text = "Batch Name :";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(43, 199);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(56, 13);
            this.label4.TabIndex = 3;
            this.label4.Text = "Comments";
            // 
            // txtEmployeeID
            // 
            this.txtEmployeeID.Location = new System.Drawing.Point(139, 17);
            this.txtEmployeeID.Name = "txtEmployeeID";
            this.txtEmployeeID.Size = new System.Drawing.Size(286, 20);
            this.txtEmployeeID.TabIndex = 4;
            // 
            // txtModuleName
            // 
            this.txtModuleName.Location = new System.Drawing.Point(139, 61);
            this.txtModuleName.Name = "txtModuleName";
            this.txtModuleName.Size = new System.Drawing.Size(286, 20);
            this.txtModuleName.TabIndex = 5;
            // 
            // txtBatchName
            // 
            this.txtBatchName.Location = new System.Drawing.Point(139, 108);
            this.txtBatchName.Name = "txtBatchName";
            this.txtBatchName.Size = new System.Drawing.Size(286, 20);
            this.txtBatchName.TabIndex = 6;
            // 
            // txtcomments
            // 
            this.txtcomments.AllowDrop = true;
            this.txtcomments.Location = new System.Drawing.Point(139, 155);
            this.txtcomments.Multiline = true;
            this.txtcomments.Name = "txtcomments";
            this.txtcomments.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtcomments.ScrollBars = System.Windows.Forms.ScrollBars.Vertical;
            this.txtcomments.Size = new System.Drawing.Size(286, 116);
            this.txtcomments.TabIndex = 7;
            // 
            // btnaddentry
            // 
            this.btnaddentry.Location = new System.Drawing.Point(226, 291);
            this.btnaddentry.Name = "btnaddentry";
            this.btnaddentry.Size = new System.Drawing.Size(75, 23);
            this.btnaddentry.TabIndex = 8;
            this.btnaddentry.Text = "Add Entry";
            this.btnaddentry.UseVisualStyleBackColor = true;
            this.btnaddentry.Click += new System.EventHandler(this.btnAddEntry_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(637, 341);
            this.Controls.Add(this.btnaddentry);
            this.Controls.Add(this.txtcomments);
            this.Controls.Add(this.txtBatchName);
            this.Controls.Add(this.txtModuleName);
            this.Controls.Add(this.txtEmployeeID);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox txtEmployeeID;
        private System.Windows.Forms.TextBox txtModuleName;
        private System.Windows.Forms.TextBox txtBatchName;
        private System.Windows.Forms.TextBox txtcomments;
        private System.Windows.Forms.Button btnaddentry;
    }
}

