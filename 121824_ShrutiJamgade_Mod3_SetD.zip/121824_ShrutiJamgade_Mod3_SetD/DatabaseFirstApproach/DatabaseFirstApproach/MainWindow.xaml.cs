﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace DatabaseFirstApproach
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_18Jan2017_TalwadeEntities custEntity = new Training_18Jan2017_TalwadeEntities();
        Customer_DN121824 customer;

        public MainWindow()
        {
            InitializeComponent();
        }

        private void datagridview_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
        //Button to display the custtomer record who are from MUMBAI
        private void button2_Click(object sender, RoutedEventArgs e)
        {
            var query = from cust in custEntity.Customer_DN121824
                        where cust.City=="Mumbai"
                        select cust;
            if (query != null)
            {
                datagridview.ItemsSource = query.ToList();
            }
            else
            {
                MessageBox.Show("No Records available to display");
            }
           
        }
    }
}
