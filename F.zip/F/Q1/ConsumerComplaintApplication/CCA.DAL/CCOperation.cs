﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using CCA.Entity;
using CCA.Exception;

namespace CCA.DAL
{
    public class CCOperation
    {
        SqlConnection connection;
        SqlDataReader reader;

        public CCOperation()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["ConsCompConn"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
         public bool AddComplaintRecord(ConsumerComplaint conCompObj)
        {
            try
            {
                bool compAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddConsCompl_121649", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@ConsumerEID", conCompObj.ConsumerEID);
                cmdAdd.Parameters.AddWithValue("@Category", conCompObj.Category);
                cmdAdd.Parameters.AddWithValue("@ProductName", conCompObj.ProductName);
                cmdAdd.Parameters.AddWithValue("@DateofPurchase", conCompObj.DoP);
                cmdAdd.Parameters.AddWithValue("@DealerDetails", conCompObj.DealerDetails);
                cmdAdd.Parameters.AddWithValue("@ProductValue", conCompObj.ProductValue);
                cmdAdd.Parameters.AddWithValue("@City", conCompObj.city);
                cmdAdd.Parameters.AddWithValue("@ComplaintDetails", conCompObj.complaintDetails);

                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    compAdded = true;
                return compAdded;
            }
            catch (CCException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
           }
            //catch (SystemException)
            //{
            //    throw;
            //}
            
            finally
            {
                connection.Close();
            }
        }
        public bool CompareConsumerEID(string consumerEID)
        {
            try
            {
                bool consEID = false;
                SqlCommand cmdGetConsumerID = new SqlCommand("RetrieveConsID_121649", connection);
                cmdGetConsumerID.CommandType = CommandType.StoredProcedure;
                cmdGetConsumerID.Parameters.AddWithValue("@ConsumerEID", consumerEID);
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdGetConsumerID.ExecuteReader();
                DataTable dt = new DataTable();
                dt.Load(reader);
                int result = Convert.ToInt32(dt.Rows[0][0]);
                if (result > 0)
                    consEID = true;
                return consEID;
            }
            catch (CCException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            //catch (SystemException)
            //{
            //    throw;
            //}

            finally
            {
                connection.Close();
            }
        }

        //public bool CompareConsumerName(string consumerName)
        //{
        //    bool consN = false;
        //    SqlCommand cmdGetConsumerName = new SqlCommand("RetrieveConsID_121649", connection);
        //    cmdGetConsumerName.CommandType = CommandType.StoredProcedure;
        //    cmdGetConsumerName.Parameters.AddWithValue("@ConsumerName", consumerName);
        //    if (connection.State == ConnectionState.Closed)
        //        connection.Open();
        //    reader = cmdGetConsumerName.ExecuteReader();
        //    DataTable dt = new DataTable();
        //    dt.Load(reader);
        //    int result = Convert.ToInt32(dt.Rows[0][0]);
        //    if (result > 0)
        //        consN = true;
        //    return consN;
        //}
    }
}
