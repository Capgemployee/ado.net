﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace savemenuitem
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void newToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void saveToolStripMenuItem_Click(object sender, EventArgs e)
        {
            string filename = null;
            if (toolStripStatusLabel1.Text == "Saved")
            {

            }

            else if (toolStripStatusLabel1.Text == "Unsaved" && toolStripStatusLabel2.Text != String.Empty)
            {
                FileStream fs = new FileStream(toolStripStatusLabel2.Text, FileMode.OpenOrCreate, FileAccess.Write);
                StreamWriter sw = new StreamWriter(fs);
                string st = textBox1.Text;
                sw.WriteLine(st);
                sw.Flush();
                fs.Close();
                toolStripStatusLabel1.Text = "Saved";
            }
            else if (toolStripStatusLabel1.Text == "Unsaved" && toolStripStatusLabel2.Text == String.Empty)
            {
                if (saveFileDialog1.ShowDialog() == DialogResult.OK)
                {
                    filename = saveFileDialog1.FileName;
                    FileStream fs = new FileStream(saveFileDialog1.FileName, FileMode.Create, FileAccess.Write);
                    StreamWriter sw = new StreamWriter(fs);
                    string st = textBox1.Text;
                    sw.WriteLine(st);
                    sw.Flush();
                    fs.Close();
                    toolStripStatusLabel1.Text = "Saved";
                    toolStripStatusLabel2.Text = filename;
                }
            }
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            toolStripStatusLabel1.Text = "Unsaved";
        }
    }
}
