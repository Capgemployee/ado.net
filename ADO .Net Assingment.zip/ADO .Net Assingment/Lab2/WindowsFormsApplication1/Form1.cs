﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace WindowsFormsApplication1
{
    public partial class Form1 : Form
    {
        SqlConnection con;
        SqlDataAdapter da;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;Integrated Security=False;User ID=sqluser;Password=sqluser;Connect Timeout=15;Encrypt=False;TrustServerCertificate=False");
            con.Open();
            ds = new DataSet();
            da = new SqlDataAdapter("Select * from applicationusers_121699", con);
            SqlCommandBuilder bld = new SqlCommandBuilder(da);
            da.Fill(ds, "appusers");
            dataGridView1.DataSource=ds.Tables["appusers"];
        }

        private void button1_Click(object sender, EventArgs e)
        {
            ds.Tables["appusers"].RejectChanges();
            Environment.Exit(0);
        }

        private void button2_Click(object sender, EventArgs e)
        {
            try
            {
                da.Update(ds.Tables["appusers"]);
                MessageBox.Show("Changes Saved");
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            foreach (DataRow drow  in ds.Tables["appusers"].Rows)
            {
                if (drow.RowState==DataRowState.Deleted)
                {
                    MessageBox.Show(drow["username", DataRowVersion.Original].ToString() + " deleted");

                }
                else
                {
                    MessageBox.Show(drow["username"].ToString()+""+drow.RowState.ToString());
                }
            }
        }
    }
}
