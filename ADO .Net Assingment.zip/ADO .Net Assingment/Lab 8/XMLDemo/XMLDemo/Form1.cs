﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data;
using System.Xml;
using System.Data.SqlClient;

namespace XMLDemo
{
    public partial class Form1 : Form
    {
        XmlDocument doc;
        DataSet ds;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void btnload_Click(object sender, EventArgs e)
        {
            doc = new XmlDataDocument();
            // Load the schema file.
            doc.DataSet.ReadXmlSchema("BookStore.xsd");
            // Load the XML data.
            XmlTextReader reader = new XmlTextReader("Books.xml");
            // Move the reader to the root node and load xml data
            reader.MoveToContent();
            doc.Load(reader);
            // Update the price on the first book using the DataSet methods.
            // Working with data as relational model
            DataTable books = doc.DataSet.Tables["book"];
            books.Rows[0]["price"] = "101.95";
            grdbook.DataSource = doc.DataSet.Tables["book"];
            btnload.Enabled = false;
            btnshowtitles.Enabled = true;
        }

        private void btnshowtitles_Click(object sender, EventArgs e)
        {
            // Get the node list of titles of type ‘novel’
            // Working with data as heirarchical model
            XmlNodeList nodelist = doc.DocumentElement.SelectNodes
            ("//title[../@genre = 'novel']");
            string msg = "";
            foreach (XmlNode node in nodelist)
            {
                msg += node.InnerText + "\n";
            }
            MessageBox.Show(msg);
        }
    }
}
