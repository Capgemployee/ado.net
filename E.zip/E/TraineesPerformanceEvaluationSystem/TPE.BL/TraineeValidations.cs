﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Text.RegularExpressions;
using TPE.Entity;
using TPE.DAL;
using TPE.CustomException;

namespace TPE.BL
{
    /// <summary>
    /// Class containing Database operations
    /// Author: Miss.Shraddha Surve
    /// Date Modified: 14 March 2017
    /// Version No:1
    /// Change Description: This class is built to deal with Trainee's performance data
    /// </summary>
    public class TraineeValidations
    {
        TraineeOperations operationObj = new TraineeOperations();

        /// <summary>
        /// Method to validate Trainee record
        /// Author: Miss.Shraddha Surve
        /// Date Modified: 14 march 2017
        /// Version No:1
        /// Change Description: Method to validate the trainee performance details
        /// </summary>
        /// <param name="traineeObj"></param>
        /// <returns>bool</returns>
        public bool ValidateTrainee(Trainee traineeObj)
        {
            bool validTrainee = true;
            StringBuilder sb = new StringBuilder();
            if (traineeObj.EmployeeID.ToString().Length == 0)
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Employee ID is required.");
            }
            if (traineeObj.ModuleName.Length == 0)
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Module Name is required.");
            }
            if (traineeObj.BatchName.Length == 0)
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Batch Name is required.");
            }
            if (traineeObj.Comments.Length == 0)
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Comments are required.");
            }
            if (!(Regex.IsMatch(traineeObj.EmployeeID.ToString(), @"^[0-9]+$")))
            {
                validTrainee = false;
                sb.Append(Environment.NewLine + "Employee ID should contain only numbers.");
            }


            if (validTrainee == false)
                throw new TraineeExceptions(sb.ToString());
            return validTrainee;
        }

        /// <summary>
        /// Method that calls a method that adds a Trainee's Performance Record
        /// Author: Miss.Shraddha Surve
        /// Date Modified: 14 march 2017
        /// Version No:1
        /// Change Description: Method to Add a Trainee's Performance Record
        /// </summary>
        /// <param name="traineeObj"></param>
        /// <returns>bool</returns>
        public bool AddTraineePerformance(Trainee traineeObj)
        {
            bool traineeAdded = false;
            if (ValidateTrainee(traineeObj))
                traineeAdded = operationObj.AddTraineePerformanceDetails(traineeObj);
            return traineeAdded;
        }



    }
}
