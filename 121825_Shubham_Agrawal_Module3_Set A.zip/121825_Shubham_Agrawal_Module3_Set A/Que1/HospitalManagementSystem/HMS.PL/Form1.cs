﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using HMS.Entity;
using HMS.Exception;
using HMS.BL;
using System.Data.SqlClient;

namespace HMS.PL
{
    public partial class Form1 : Form
    {
        PatientValidations validationsObj = new PatientValidations();
        public Form1()
        {
            InitializeComponent();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            try
            {
                Patient patientObj = new Patient();
                
                patientObj.FirstName = txtFirstName.Text;
                patientObj.LastName = txtLastName.Text;
                patientObj.Gender = radMale.Text;
                patientObj.DateAndTime = txtDate.Text;
                patientObj.Address = txtAddress.Text;
                patientObj.City = txtCity.Text;
                patientObj.State = txtState.Text;
                patientObj.Pincode = txtPincode.Text;
                patientObj.Mobile = txtPhone.Text;

                bool patientAdded = validationsObj.AddPatientRecord(patientObj);
                if (patientAdded)
                    MessageBox.Show("patient Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add patient record", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (PatientException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            //catch (SystemException ex)
            //{
            //    MessageBox.Show(ex.Message);
            //}
        }

        private void btnDisplay_Click(object sender, EventArgs e)
        {
            DataTable patientTable = new DataTable();
            bool isNumber;
            int result;
            isNumber = int.TryParse(txtID.Text, out result);
            if (isNumber)       
                patientTable = validationsObj.GetPatientRecord(result);
            else
            {   
                MessageBox.Show("Please enter only numbers in Guest ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return;
            }
            dgvPatient.DataSource = patientTable;
        }



    }
}
