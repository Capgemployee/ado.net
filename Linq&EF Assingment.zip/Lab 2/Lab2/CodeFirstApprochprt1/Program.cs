﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace CodeFirstApprochprt1
{
    class Program
    {
        static void Main(string[] args)
        {
            ProductContext prodcntxt = new ProductContext();

            Products_121653 prod1 = new Products_121653()
            {
            ProductId = 101, Name = "Remort Controlling Car", Category="Toys",Price= 899
            };

            Products_121653 prod2 = new Products_121653()
            {
            ProductId = 102, Name = "Lab Books", Category="Stationary", Price=1599
            };

            prodcntxt.Products_details.Add(prod1);
            prodcntxt.Products_details.Add(prod2);
            prodcntxt.SaveChanges();

            Console.Write("Product Details are added SuccessFully:");

            Console.ReadLine();
        }
    }
}
