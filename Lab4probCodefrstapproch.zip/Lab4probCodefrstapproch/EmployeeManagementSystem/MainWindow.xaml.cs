﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeManagementSystem
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }
        EmployeeContext econtext = new EmployeeContext();
        EmployeeCB obj = new EmployeeCB();

        private void datagridview_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void btnsave_Click(object sender, RoutedEventArgs e)
        {
            obj.Empno = Convert.ToInt32(empid.Text);
            obj.Empname = empname.Text;
            obj.EmpDOB = Convert.ToDateTime(empdob.Text);
            obj.EmpDOJ = Convert.ToDateTime(empdoj.Text);
            obj.EmpDesg = empdesg.Text;
            obj.EmpSal = Convert.ToDouble(empsal.Text);

            econtext.EmpTable.Add(obj);
            econtext.SaveChanges();
            MessageBox.Show("Employee Added sucessfully");
            btndeleete.IsEnabled = true;
            empid.Clear();
            empname.Clear();
            empdob.Clear();
            empdoj.Clear();
            empdesg.Clear();
            empsal.Clear();
        }

        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                    obj.Empname = empname.Text;
                    obj.EmpDOB = Convert.ToDateTime(empdob.Text);
                    obj.EmpDOJ = Convert.ToDateTime(empdoj.Text);
                    obj.EmpDesg = empdesg.Text;
                    obj.EmpSal = Convert.ToDouble(empsal.Text);
                    econtext.SaveChanges();
                    MessageBox.Show("Employee Updated");
                    empid.Clear();
                    empname.Clear();
                    empdob.Clear();
                    empdoj.Clear();
                    empdesg.Clear();
                    empsal.Clear();
               
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
        }

        private void btndeleete_Click(object sender, RoutedEventArgs e)
        {
            econtext.EmpTable.Remove(obj);
            econtext.SaveChanges();
            MessageBox.Show("Employee Deleted");
            empid.Clear();
            empname.Clear();
            empdob.Clear();
            empdoj.Clear();
            empdesg.Clear();
            empsal.Clear();
        }

        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            int a = Convert.ToInt32(empid.Text);
            var searchquery = (from eq in econtext.EmpTable
                               where eq.Empno == a
                               select eq).FirstOrDefault();
            if (searchquery != null)
            {
                obj = searchquery;

                empname.Text = obj.Empname;
                empdob.Text = obj.EmpDOB.ToString();
                empdoj.Text = obj.EmpDOJ.ToString();
                empdesg.Text = obj.EmpDesg.ToString();
                empsal.Text = obj.EmpSal.ToString();

            }
            else
            {
                MessageBox.Show("EMPLOYEE NOT FOUND");
            }
        }

        private void btndisplay_Click(object sender, RoutedEventArgs e)
        {
            var query = from a in econtext.EmpTable
                        select a;
            datagridview.ItemsSource = query.ToList();

            empid.Clear();
        }

        private void btnnew_Click(object sender, RoutedEventArgs e)
        {
            empid.Clear();
            empname.Clear();
            empdob.Clear();
            empdoj.Clear();
            empdesg.Clear();
            empsal.Clear();
        }

        private void empdetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        private void ViewEmp_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
