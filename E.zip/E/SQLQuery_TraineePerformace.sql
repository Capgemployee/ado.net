CREATE TABLE TraineePerformance_121823
(
	EmployeeID int,
	ModuleName varchar(30),
	BatchName varchar(40),
	Comments varchar(200)
)
go
Alter PROCEDURE AddTraineePerformance_121823
(
	@EmployeeID int,
	@ModuleName varchar(30),
	@BatchName varchar(40),
	@Comments varchar(200)
)
AS
INSERT INTO TraineePerformance_121823
VALUES(@EmployeeID,@ModuleName,@BatchName,@Comments)

EXEC AddTraineePerformance_121823 101,'Module 1','.NET','Good'

go
Alter PROCEDURE GetAllTraineePerformance
AS
SELECT * FROM TraineePerformance_121823

EXEC GetAllTraineePerformance