﻿namespace XMLDemo
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.grdbook = new System.Windows.Forms.DataGridView();
            this.btnload = new System.Windows.Forms.Button();
            this.btnshowtitles = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.grdbook)).BeginInit();
            this.SuspendLayout();
            // 
            // grdbook
            // 
            this.grdbook.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.grdbook.Location = new System.Drawing.Point(25, 54);
            this.grdbook.Name = "grdbook";
            this.grdbook.Size = new System.Drawing.Size(623, 275);
            this.grdbook.TabIndex = 0;
            // 
            // btnload
            // 
            this.btnload.Location = new System.Drawing.Point(289, 13);
            this.btnload.Name = "btnload";
            this.btnload.Size = new System.Drawing.Size(104, 35);
            this.btnload.TabIndex = 1;
            this.btnload.Text = "Load XML Data";
            this.btnload.UseVisualStyleBackColor = true;
            this.btnload.Click += new System.EventHandler(this.btnload_Click);
            // 
            // btnshowtitles
            // 
            this.btnshowtitles.Enabled = false;
            this.btnshowtitles.Location = new System.Drawing.Point(427, 13);
            this.btnshowtitles.Name = "btnshowtitles";
            this.btnshowtitles.Size = new System.Drawing.Size(104, 35);
            this.btnshowtitles.TabIndex = 2;
            this.btnshowtitles.Text = "Show Titles";
            this.btnshowtitles.UseVisualStyleBackColor = true;
            this.btnshowtitles.Click += new System.EventHandler(this.btnshowtitles_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(673, 341);
            this.Controls.Add(this.btnshowtitles);
            this.Controls.Add(this.btnload);
            this.Controls.Add(this.grdbook);
            this.Name = "Form1";
            this.Text = "Form1";
            this.Load += new System.EventHandler(this.Form1_Load);
            ((System.ComponentModel.ISupportInitialize)(this.grdbook)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView grdbook;
        private System.Windows.Forms.Button btnload;
        private System.Windows.Forms.Button btnshowtitles;
    }
}

