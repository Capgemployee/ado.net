﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CCA.Exception
{
    public class CCException : ApplicationException
    {
         // default constructor 
        public CCException() 
           : base()
        { }

        //parameterized constructor
        public CCException(string message)
            : base(message)
        { }
    }
}
