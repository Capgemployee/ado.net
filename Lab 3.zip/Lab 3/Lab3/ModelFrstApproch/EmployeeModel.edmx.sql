
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 03/09/2017 18:59:07
-- Generated from EDMX file: D:\AyushiBajpai_Assingment\ASP.Net Pract\Linq&EF Assingment\Lab 3\Lab3\ModelFrstApproch\EmployeeModel.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Training_18Jan2017_Talwade];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------


-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Employee_121653'
CREATE TABLE [dbo].[Emp_121653] (
    [EmplyID] int IDENTITY(1,1) NOT NULL,
    [EmplyName] nvarchar(max)  NOT NULL,
    [EmplyDOB] nvarchar(max)  NOT NULL,
    [EmplyAddress_Locality_] nvarchar(max)  NOT NULL,
    [EmplyAddress_City_] nvarchar(max)  NOT NULL,
    [EmplyAddress_StreetName_] nvarchar(max)  NOT NULL,
    [EmplyAddress_PinCode_] int  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [EmplyID] in table 'Employee_121653'
ALTER TABLE [dbo].[Emp_121653]
ADD CONSTRAINT [PK_Emp_121653]
    PRIMARY KEY CLUSTERED ([EmplyID] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------