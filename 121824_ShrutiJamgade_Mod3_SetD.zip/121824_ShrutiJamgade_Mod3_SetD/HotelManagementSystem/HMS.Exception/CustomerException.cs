﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Exception
{
    /// <summary>
    /// Employee ID :121824
    /// Employee Name : SHRUTI JAMGADE
    /// Description : This class has the Customer Structure
    /// Date of Creation : 03/14/2017
    /// </summary>
    public class CustomerException:ApplicationException
    {
        //Default Constructor of CustomerException
         public CustomerException()
             : base() 
         { }

         //Parameterized Constructor of CustomerException
         public CustomerException(string message) 
             : base(message)
         { }
    }
}
