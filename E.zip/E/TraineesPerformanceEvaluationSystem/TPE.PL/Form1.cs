﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using TPE.Entity;
using TPE.CustomException;
using TPE.BL;
using System.Data.SqlClient;

namespace TPE.PL
{
    /// <summary>
    /// Class containing user interaction code
    /// Author: Miss.Shraddha Surve
    /// Date Modified: 14 March 2017
    /// Version No:1
    /// Change Description: This class is built to deal with user interactions
    /// </summary>
    public partial class Form1 : Form
    {
        TraineeValidations validationsObj = new TraineeValidations();
        public Form1()
        {
            InitializeComponent();
        }

        /// <summary>
        /// Method to add trainee's record
        /// Author: Miss.Shraddha Surve
        /// Date Modified: 14 march 2017
        /// Version No:1
        /// Change Description: This is a method to add trainee's performance details
        /// </summary>
        /// <param name="traineeObj"></param>
        private void btnAddEntry_Click(object sender, EventArgs e)
        {
            try
            {
                Trainee traineeObj = new Trainee();
                bool isNumber;
                int result;
                isNumber = int.TryParse(txtEmployeeID.Text, out result);
                if (isNumber)
                    traineeObj.EmployeeID = result;
                else
                {
                    MessageBox.Show("Please enter only numbers in Employee ID field", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    return;
                }
                traineeObj.ModuleName = txtModuleName.Text;
                traineeObj.BatchName = txtBatchName.Text;
                traineeObj.Comments = txtcomments.Text;

                bool traineeAdded = validationsObj.AddTraineePerformance(traineeObj);
                if (traineeAdded)
                    MessageBox.Show("Trainee's Performance Details Added Successfully", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                else
                    MessageBox.Show("Failed to add Trainee's Performance Details", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            catch (TraineeExceptions ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (SqlException ex)
            {
                MessageBox.Show(ex.Message);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }


        private void Form1_Load(object sender, EventArgs e)
        {

        }
    }
}
