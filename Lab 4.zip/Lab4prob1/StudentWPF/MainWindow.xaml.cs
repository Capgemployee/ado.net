﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace StudentWPF
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        Training_18Jan2017_TalwadeEntities1 tr = new Training_18Jan2017_TalwadeEntities1();

        private void staffdetails_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var query = from b in tr.Staff_Master
                        select b;
            staffgrid.ItemsSource = query.ToList();
        }

        private void studentAcSalary_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            var query1 = from b in tr.Student_master
                         select b;
            studentAcSalary.ItemsSource = query1.ToList();
        }

        private void txtstud_Code_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtStud_Name_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtDep_Code_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtDOB_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void txtAddress_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            //if (txtstud_Code.Text == "" || txtStud_Name.Text == "" || txtDep_Code.Text == "" || txtstud_Code.Text == "" || txtAddress.Text == "")
            //{
            //    MessageBox.Show("Please all the details properly", "Error", MessageBoxButton.OK);
            //}
            //else
            //{
            //    try
            //    {
            //         emp = new Employee();
            //        emp.FirstName = txtFname.Text;
            //        emp.LastName = txtLname.Text;
            //        emp.Gender = cboGender.Text;
            //        emp.DOB = dtpDOB.Text;
            //        emp.Designation = cboDesign.Text;
            //        emp.Email = txtEmail.Text;

            //        employeeContext.Employees.Add(emp);
            //        employeeContext.SaveChanges();

            //        MessageBox.Show("Employee Addedd Sucessfully....");

            //        ResetFields();
            //    }
            //    catch (Exception ex)
            //    {
            //        MessageBox.Show(ex.Message);
            //    }
            //}
        }

        private void btnUpdate_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnDelete_Click(object sender, RoutedEventArgs e)
        {

        }

        private void btnSearch_Click(object sender, RoutedEventArgs e)
        {

        }
    }
}
