﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using HMS.Entity;
using HMS.Exception;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;

namespace HMS.DAL
{
    /// <summary>
    /// Employee ID :121825
    /// Employee Name : Shubham Agrawal
    /// Description : Patient operations class to deal with the Patient data
    /// Version:1.0
    /// Last Modified Date : 14-March-2017
    /// Date of Creation : 14-March-2017
    /// </summary>
    public class PatientOperations
    {
         SqlConnection connection;
        SqlDataReader reader;

        public PatientOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["HMS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Method to add Patient record
        /// Author: Shubham Agrawal
        /// Date Modified: 14-March-2017
        /// Version No:
        /// Change Description: 
        /// </summary>
        /// <param name="patientObj"></param>
        /// <returns>bool</returns>
        public bool AddPatientRecord(Patient guestObj)
        {
            try
            {
                bool patientAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddPatient", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@FirstName", guestObj.FirstName);
                cmdAdd.Parameters.AddWithValue("@LastName", guestObj.LastName);
                cmdAdd.Parameters.AddWithValue("@Gender", guestObj.Gender);
                cmdAdd.Parameters.AddWithValue("@DateAndTime", guestObj.DateAndTime);
                cmdAdd.Parameters.AddWithValue("@Address", guestObj.Address);
                cmdAdd.Parameters.AddWithValue("@City", guestObj.City);
                cmdAdd.Parameters.AddWithValue("@State", guestObj.State);
                cmdAdd.Parameters.AddWithValue("@Pincode", guestObj.Pincode);
                cmdAdd.Parameters.AddWithValue("@PhoneNo", guestObj.Mobile);

                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    patientAdded = true;
                return patientAdded;
            }
            catch (PatientException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            catch (SystemException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }
        /// <summary>
        /// Method to return Patient information
        /// Author: Shubham Agrawal
        /// Date Modified: 14-March-2017
        /// Version No: 
        /// </summary>
        /// <param name="patientID"></param>
        /// <returns></returns>
        public DataTable GetPatientRecord(int patientID)
        {
            SqlCommand cmdGetPatient = new SqlCommand("SP_RetrievePatientInfo", connection);
            cmdGetPatient.CommandType = CommandType.StoredProcedure;
            cmdGetPatient.Parameters.AddWithValue("@PatientID", patientID);
            if (connection.State == ConnectionState.Closed)
                connection.Open();
            reader = cmdGetPatient.ExecuteReader();
            DataTable patientTable = new DataTable();
            patientTable.Load(reader);
            return patientTable;
        }
    }
}
