﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmployeeForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        SqlConnection con;
        SqlCommand cmd;


        private void EmployeeForm_Load(object sender, EventArgs e)
        {
           
        }

        private void btnquery_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;User ID=sqluser;Password=sqluser");
            con.Open();
            try
            {

                SqlDataReader dreader = null;

                //The Procedure to execute
                SqlCommand cmd = new SqlCommand("procGetEmployeeById_121653", con);
                cmd.CommandType = CommandType.StoredProcedure;

                //define procedure parameter
                SqlParameter prm;
                prm = new SqlParameter();
                prm.SqlDbType = SqlDbType.Int;
                prm.Direction = ParameterDirection.Input;
                prm.ParameterName = "@eno";
                cmd.Parameters.Add(prm);

                //assign parameter value
                cmd.Parameters["@eno"].Value = int.Parse(txtempno.Text);



                //execute
                dreader = cmd.ExecuteReader();

                //if employee record found
                if (dreader.Read())
                {
                    txtempname.Text = dreader["empname"].ToString();
                    txtsalary.Text = dreader["empsal"].ToString();
                    if (dreader["emptype"].ToString() == "P")
                        rdpayroll.Checked = true;
                    else
                        rdconsultant.Checked = true;
                }
                else
                {
                    btnnew_Click(btnnew, e);
                    MessageBox.Show("No such employee");
                }
                dreader.Close();
                
            }

            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }

            finally
            {
                con.Close();
            }

        }

        private void btnsave_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;User ID=sqluser;Password=sqluser");
            con.Open();
            try
            {

                //The Insert DML to add employee record
                SqlCommand cmd = new SqlCommand
                ("insert into DNEmployee_121653 values(@eno,@enm,@esal,@etyp)", con);

                //The Parameters
                cmd.Parameters.Add("@eno", SqlDbType.Int);
                cmd.Parameters.Add("@enm", SqlDbType.VarChar, 50);
                cmd.Parameters.Add("@esal", SqlDbType.Decimal);
                cmd.Parameters.Add("@etyp", SqlDbType.VarChar, 1);
                //Assigning Values to parameters
                cmd.Parameters["@eno"].Value = txtempno.Text;
                cmd.Parameters["@enm"].Value = txtempname.Text;
                cmd.Parameters["@esal"].Value = txtsalary.Text;
                cmd.Parameters["@etyp"].Value = rdpayroll.Checked == true ? "P" : "C";


                //Execute Insert ....
                cmd.ExecuteNonQuery();
                MessageBox.Show("Employee Details Saved");
            }
            catch (SqlException sqlex)
            {
                MessageBox.Show(sqlex.Message);
            }

            finally
            {
                con.Close();
            }
        }

        private void btnnew_Click(object sender, EventArgs e)
        {
            txtempno.Text = "";
            txtempname.Text = "";
            txtsalary.Text = "";
            txtempno.Focus();
            //rdpayroll = false;
            //rdconsultant = false;
        }

        private void btndelete_Click(object sender, EventArgs e)
        {
            con = new SqlConnection(@"Data Source=NDAMSSQL\SQLILEARN;Initial Catalog=Training_18Jan2017_Talwade;User ID=sqluser;Password=sqluser");
            con.Open();
             MessageBox.Show("Are you sure you want to Delete this Details?", "Confirm",
               MessageBoxButtons.OKCancel, MessageBoxIcon.Question);
             try
             {
                 SqlCommand cmd = new SqlCommand("Delete From DNEmployee_121653 Where empno=@eno",con);
                 cmd.Parameters.Add("@eno", SqlDbType.Int);
                 cmd.Parameters["@eno"].Value = txtempno.Text;
                 txtempno.Text = "";
                 txtempname.Text = "";
                 txtsalary.Text = "";
                 txtempno.Focus();
                 //rdpayroll = false;
                 //rdconsultant = false;
             }
             catch (SqlException sqlex)
             {
                 MessageBox.Show(sqlex.Message);
             }

             finally
             {
                 con.Close();
             }
        }


    }
}
