﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace WindowaApplication
{
    public partial class frmAayu : Form
    {
        public frmAayu()
        {
            InitializeComponent();
            Size = new Size(400, 400);
            Text = "Ayushi Bajpai WindowaApplication";
        }

        private void frmAayu_Load(object sender, EventArgs e)
        {
            MessageBox.Show("Hello From Aayushi");
        }

        private void frmAayu_FormClosing(object sender, FormClosingEventArgs e)
        {
            DialogResult result = MessageBox.Show
                ("Are you sure you want to close this Form?","Confirm",
                MessageBoxButtons.OKCancel, MessageBoxIcon.Question);

            if (result == DialogResult.OK)
                e.Cancel = false;
            else
                e.Cancel = true;
        }

        private void frmAayu_Load_1(object sender, EventArgs e)
        {

        }

    }
}
