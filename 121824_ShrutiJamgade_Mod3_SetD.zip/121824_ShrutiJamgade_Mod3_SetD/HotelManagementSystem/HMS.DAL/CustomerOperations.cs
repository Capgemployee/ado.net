﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using HMS.Entity;              //Taking Reference of Entity Classes
using HMS.Exception;            //Taking Reference of Exception Classes


namespace HMS.DAL
{
    /// <summary>
    /// Employee ID :121824
    /// Employee Name : SHRUTI JAMGADE
    /// Description : Customer operations class to deal with the Customer data
    /// Date of Creation :  03/14/2017
    /// </summary>
    public class CustomerOperations
    {
        SqlConnection connection;
        SqlDataReader reader;

        //Providing connection within the constructor
        public CustomerOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["HMS"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }

        //Method for adding new customer details in customer
        public bool AddCustomerRecord(Customer custObj)
        {
            try
            {
                bool customerAdded = false;
                SqlCommand cmdAdd = new SqlCommand("AddCust_DN121824", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@CustomerID", custObj.CustomerID);
                cmdAdd.Parameters.AddWithValue("@CustomerName", custObj.CustomerName);
                cmdAdd.Parameters.AddWithValue("@Address", custObj.Address);
                cmdAdd.Parameters.AddWithValue("@Landmark", custObj.Landmark);
                cmdAdd.Parameters.AddWithValue("@City", custObj.City);
                cmdAdd.Parameters.AddWithValue("@Pincode", custObj.PinCode);
                cmdAdd.Parameters.AddWithValue("@ContactNo", custObj.ContactNo);
                cmdAdd.Parameters.AddWithValue("@EmailID", custObj.EmailID);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    customerAdded = true;
                return customerAdded;
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

        //Method for displaying all customer details from the customer
        public DataTable DisplayGuestRecord()
        {
            try
            {
                SqlCommand cmdDisplay = new SqlCommand("DisplayCust_DN121824", connection);
                cmdDisplay.CommandType = CommandType.StoredProcedure;
                if (connection.State == ConnectionState.Closed)
                    connection.Open();
                reader = cmdDisplay.ExecuteReader();
                DataTable customerTable = new DataTable();
                customerTable.Load(reader);
                return customerTable;
            }
            catch (CustomerException)
            {
                throw;
            }
            catch (SqlException)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }

    }
}
