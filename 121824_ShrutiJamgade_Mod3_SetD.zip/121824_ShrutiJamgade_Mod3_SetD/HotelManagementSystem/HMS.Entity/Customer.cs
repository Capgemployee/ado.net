﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace HMS.Entity
{
    /// <summary>
    /// Employee ID :121824
    /// Employee Name : SHRUTI JAMGADE
    /// Description : This class has the Customer Structure
    /// Date of Creation : 03/14/2017
    /// </summary>
    public class Customer
    {
        #region Property
        //Get or Set Customer ID
        public int CustomerID { get; set; }

        //Get or Set Customer ID
        public string CustomerName { get; set; }

        //Get or Set Address
        public string Address { get; set; }

        //Get or Set Landmark
        public string Landmark { get; set; }

        //Get or Set City
        public string City { get; set; }

        //Get or Set PinCode
        public int PinCode { get; set; }

        //Get or Set Contact No
        public long ContactNo { get; set; }

        //Get or Set Email ID
        public string EmailID { get; set; }
        #endregion

    }
}
