﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Configuration;
using TPE.Entity;
using TPE.CustomException;

namespace TPE.DAL
{
    /// <summary>
    /// Class containing Database operations
    /// Author: Miss.Shraddha Surve
    /// Date Modified: 14 March 2017
    /// Version No:1
    /// Change Description: This class is built to deal with Trainee's performance data
    /// </summary>
    public class TraineeOperations
    {
        SqlConnection connection;
       
        public TraineeOperations()
        {
            string connectionString = ConfigurationManager.ConnectionStrings["TPE"].ConnectionString;
            connection = new SqlConnection(connectionString);
        }
        /// <summary>
        /// Method to add trainee's record
        /// Author: Miss.Shraddha Surve
        /// Date Modified: 14 march 2017
        /// Version No:1
        /// Change Description: This is a method to add trainee's performance details
        /// </summary>
        /// <param name="traineeObj"></param>
        /// <returns>bool</returns>
        public bool AddTraineePerformanceDetails(Trainee traineeObj)
        {
            
            try
            {
                bool traineeAdded = false;


                SqlCommand cmdAdd = new SqlCommand("AddTraineePerformance_121823", connection);
                cmdAdd.CommandType = CommandType.StoredProcedure;
                cmdAdd.Parameters.AddWithValue("@EmployeeID", traineeObj.EmployeeID);
                cmdAdd.Parameters.AddWithValue("@ModuleName", traineeObj.ModuleName);
                cmdAdd.Parameters.AddWithValue("@BatchName",traineeObj.BatchName);
                cmdAdd.Parameters.AddWithValue("@Comments", traineeObj.Comments);
                connection.Open();
                int result = cmdAdd.ExecuteNonQuery();
                if (result > 0)
                    traineeAdded = true;
                return traineeAdded;
            }
            catch (TraineeExceptions)
            {
                throw;
            }
            //catch (SqlException)
            //{
            //    throw;
            //}
            catch (Exception)
            {
                throw;
            }
            finally
            {
                connection.Close();
            }
        }


    }
}
