﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace EmployeeLManagement
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        Training_18Jan2017_TalwadeEntities tn = new Training_18Jan2017_TalwadeEntities();
        Employee_121653 obj;
        public MainWindow()
        {
            InitializeComponent();
        }

        private void datagridview_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //var dspquery = from a in tn.Employee_121653
            //               select a;
            //ViewEmp.ItemsSource = dspquery.ToList();
        }

        //addind record
        private void btnsave_Click(object sender, RoutedEventArgs e)
        {
            Employee_121653 obj = new Employee_121653();
            obj.Empno = Convert.ToInt32(empid.Text);
            obj.Empname = empname.Text;
            obj.EmpDOB = Convert.ToDateTime(empdob.Text);
            obj.EmpDOJ = Convert.ToDateTime(empdoj.Text);
            obj.EmpDesg = empdesg.Text;
            obj.Empsal = Convert.ToDecimal(empsal.Text);

            tn.Employee_121653.Add(obj);
            tn.SaveChanges();
            MessageBox.Show("Employee Added sucessfully");
            btndeleete.IsEnabled = true;
            empid.Clear();
            empname.Clear();
            empdob.Clear();
            empdoj.Clear();
            empdesg.Clear();
            empsal.Clear();
        }

        private void btnupdate_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                int a = Convert.ToInt32(empid.Text);
                var updatequery = (from eq in tn.Employee_121653
                                   where eq.Empno == a
                                   select eq).FirstOrDefault();
                if (updatequery != null)
                {

                    obj.Empname = empname.Text;
                    obj.EmpDOB = Convert.ToDateTime(empdob.Text);
                    obj.EmpDOJ = Convert.ToDateTime(empdoj.Text);
                    obj.EmpDesg = empdesg.Text;
                    obj.Empsal = Convert.ToDecimal(empsal.Text);
                    tn.SaveChanges();
                    MessageBox.Show("Employee Updated");
                    empid.Clear();
                    empname.Clear();
                    empdob.Clear();
                    empdoj.Clear();
                    empdesg.Clear();
                    empsal.Clear();

                }
                else
                {
                    MessageBox.Show("Invalid Employee ID");

                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }

        }

        private void btndeleete_Click(object sender, RoutedEventArgs e)
        {
            tn.Employee_121653.Remove(obj);
            tn.SaveChanges();
            MessageBox.Show("Employee Deleted");
        }

        //Search for the Employee
        private void btnsearch_Click(object sender, RoutedEventArgs e)
        {
            int a = Convert.ToInt32(empid.Text);
            var searchquery = (from eq in tn.Employee_121653
                         where eq.Empno == a
                         select eq).FirstOrDefault();
            if (searchquery != null)
            {
                obj = searchquery;

                empname.Text = obj.Empname;
                empdob.Text = obj.EmpDOB.ToString();
                empdoj.Text = obj.EmpDOJ.ToString();
                empdesg.Text = obj.EmpDesg.ToString();
                empsal.Text = obj.Empsal.ToString();
                
            }
            else
            {
                MessageBox.Show("EMPLOYEE NOT FOUND");
            }
        }

        //Display Details of the Employee
        private void btndisplay_Click(object sender, RoutedEventArgs e)
        {
            var query = from a in tn.Employee_121653
                        select a;
            datagridview.ItemsSource = query.ToList();

            empid.Clear();
        }

        private void btnnew_Click(object sender, RoutedEventArgs e)
        {
            empid.Clear();
            empname.Clear();
            empdob.Clear();
            empdoj.Clear();
            empdesg.Clear();
            empsal.Clear();
        }

        private void ViewEmp_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            //var dspquery = from a in tn.Employee_121653
            //               select a;
            //ViewEmp.ItemsSource = dspquery.ToList();
        }
    }
}
