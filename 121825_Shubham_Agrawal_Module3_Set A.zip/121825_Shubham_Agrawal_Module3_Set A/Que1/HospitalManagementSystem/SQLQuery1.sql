Create TABLE Hospital_121825
(
	PatientID int IDENTITY(1,1) PRIMARY KEY,
	FirstName varchar(20),
	LastName varchar(20),
	Gender	varchar(10),
	DateAndTime Datetime,
	Address varchar(50),
	City varchar(20),
	State varchar(10),
	Pincode varchar(10),
	PhoneNo bigint
)

select * from Hospital_121825

Alter PROCEDURE AddPatient
(
	
	@FirstName varchar(30),
	@LastName varchar(30),
	@Gender	varchar(10),
	@DateAndTime Datetime,
	@Address varchar(50),
	@City varchar(20),
	@State varchar(10),
	@Pincode varchar(10),
	@PhoneNo bigint
)
AS
INSERT INTO Hospital_121825
VALUES(@FirstName,@LastName,@Gender,@DateAndTime,@Address,
		@City,@State,@Pincode,@PhoneNo)

EXEC AddPatient 'Ajinkya', 'Rahane','Male','10/10/2010','kisannagar','thane','maharashtra','400605',9876543210
EXEC AddPatient 'ravi', 'more','Male','09/10/2010','dombivli','thane','maharashtra','400666',9876543210


ALTER PROCEDURE SP_GetAllPatients
AS
SELECT * FROM Hospital_121825

EXEC GetAllPatients

ALTER PROCEDURE SP_RetrievePatientInfo
(
	@PatientID int
)
AS
SELECT * FROM Hospital_121825
WHERE PatientID=@PatientID

EXEC RetrievePatientInfo 1 


