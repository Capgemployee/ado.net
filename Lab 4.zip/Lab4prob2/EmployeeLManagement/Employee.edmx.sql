
-- --------------------------------------------------
-- Entity Designer DDL Script for SQL Server 2005, 2008, and Azure
-- --------------------------------------------------
-- Date Created: 03/11/2017 11:25:47
-- Generated from EDMX file: D:\AyushiBajpai_Assingment\ASP.Net Pract\Linq&EF Assingment\Lab 4\Lab4prob2\EmployeeLManagement\Employee.edmx
-- --------------------------------------------------

SET QUOTED_IDENTIFIER OFF;
GO
USE [Training_18Jan2017_Talwade];
GO
IF SCHEMA_ID(N'dbo') IS NULL EXECUTE(N'CREATE SCHEMA [dbo]');
GO

-- --------------------------------------------------
-- Dropping existing FOREIGN KEY constraints
-- --------------------------------------------------


-- --------------------------------------------------
-- Dropping existing tables
-- --------------------------------------------------

IF OBJECT_ID(N'[dbo].[Employee_121653]', 'U') IS NOT NULL
    DROP TABLE [dbo].[Employee_121653];
GO

-- --------------------------------------------------
-- Creating all tables
-- --------------------------------------------------

-- Creating table 'Employee_121653'
CREATE TABLE [dbo].[Employee_121653] (
    [Empno] int  NOT NULL,
    [Empname] varchar(50)  NOT NULL,
    [EmpDOB] datetime  NOT NULL,
    [EmpDOJ] datetime  NOT NULL,
    [EmpDesg] nvarchar(max)  NOT NULL,
    [Empsal] decimal(18,0)  NOT NULL
);
GO

-- --------------------------------------------------
-- Creating all PRIMARY KEY constraints
-- --------------------------------------------------

-- Creating primary key on [Empno] in table 'Employee_121653'
ALTER TABLE [dbo].[Employee_121653]
ADD CONSTRAINT [PK_Employee_121653]
    PRIMARY KEY CLUSTERED ([Empno] ASC);
GO

-- --------------------------------------------------
-- Creating all FOREIGN KEY constraints
-- --------------------------------------------------

-- --------------------------------------------------
-- Script has ended
-- --------------------------------------------------